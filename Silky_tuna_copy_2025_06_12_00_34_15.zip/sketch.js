function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}https://editor.p5js.org/ana.cardoso.fernandes/sketches